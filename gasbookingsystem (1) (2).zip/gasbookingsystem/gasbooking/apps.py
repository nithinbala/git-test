from django.apps import AppConfig


class GasbookingConfig(AppConfig):
    name = 'gasbooking'
