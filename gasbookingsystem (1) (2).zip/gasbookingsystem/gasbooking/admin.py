from django.contrib import admin
from .models import *
# Register your models here.
admin.site.register(Registration)
admin.site.register(Newconnection)
admin.site.register(Bookcylinder)
admin.site.register(Addstaff)
admin.site.register(History)
